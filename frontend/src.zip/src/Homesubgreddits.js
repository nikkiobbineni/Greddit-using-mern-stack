import { useParams } from "react-router-dom";
import './Log_in.css';
import { useNavigate } from 'react-router-dom';
import { AppBar, Toolbar, Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import Card from './Card4.js';
import { useState, useEffect } from 'react';
import { Grid } from '@material-ui/core';
const useStyles = makeStyles(() => ({ appBar: { background: 'linear-gradient(45deg, #5dc4d6 30%, #d66fc8 90%)' } }));
function Homesubgreddits() {
    const [users, setUsers] = useState("true");
    const [pendinguser, setPendinguser] = useState("false");
    const [stats, setStats] = useState("false");
    const [reportedpage, setReportedpage] = useState("false");
    const [joins, setJoins] = useState("")
    const [pending, setPending] = useState("")
    const [block, setBlock] = useState("")
    var arrj = [];
    var arrp = [];
    var arrb = [];
    const [masterarrj, setMasterarrj] = useState()
    const [masterarrp, setMasterarrp] = useState()
    const [masterarrb, setMasterarrb] = useState()
    const { name } = useParams();
    const classes = useStyles();
    const navigate = useNavigate();
    function userssetting() {
        setPendinguser("false")
        setReportedpage("false")
        setStats("false")
        setUsers("true")
    }
    function pendingsetting() {
        setPendinguser("true")
        setReportedpage("false")
        setStats("false")
        setUsers("false")
    }
    function statssetting() {
        setPendinguser("false")
        setReportedpage("false")
        setStats("true")
        setUsers("false")
    }
    function reportsetting() {
        setPendinguser("false")
        setReportedpage("true")
        setStats("false")
        setUsers("false")
    }
    function add(item) {
        // console.log(item)
        const fetchdata = async () => {
          console.log("this")
          const response = await fetch('http://localhost:5000/accept-req', {
            method: 'POST',
            body: JSON.stringify({
              "username": item,
              "name": name
            }),
            headers: {
              'Content-Type': 'application/json'
            }
          })
          const data = await response.json();
        }
        fetchdata();
      }
      function reject(item) {
        const fetchdata = async () => {
          console.log("this")
          const response = await fetch('http://localhost:5000/reject-req', {
            method: 'POST',
            body: JSON.stringify({
              "username": item,
              "name": name
            }),
            headers: {
              'Content-Type': 'application/json'
            }
          })
          const data = await response.json();
        }
        fetchdata();
      }
      // console.log("wkdjwe")
    useEffect(function () {
        const fetchCredentials = async () => {
          try {
            const response = await fetch(`http://localhost:5000/get-users/${name}`);
            const data = await response.json();
            if (response.ok) {
              const joinedusers = data.flatMap((e) => e.joinedusers);
              setMasterarrj(joinedusers);
      
              const pendingusers = data.flatMap((e) => e.pendingusers);
              setMasterarrp(pendingusers);
      
              const blockedusers = data.flatMap((e) => e.blockedusers);
              setMasterarrb(blockedusers);
            } else {
              console.error(data.error);
            }
          } catch (error) {
            console.error(error);
          }
        };
        fetchCredentials();
      }, []);
          
    console.log(masterarrp)
    function logout() {
        localStorage.removeItem('username');
        localStorage.removeItem('password');
        navigate('/');
    }
    return (
        <div>
            <div >
                <AppBar position="static" className={classes.appBar}>
                    <Toolbar>
                        <Grid container alignItems="flex-start" justify="flex-start">
                            <Grid item>
                                <Button color="inherit" onClick={userssetting}>Users</Button>
                                <Button color="inherit" onClick={pendingsetting}>Pending Request</Button>
                                <Button color="inherit" onClick={statssetting}>Statistics</Button>
                                <Button color="inherit" onClick={reportsetting}>Reported page</Button>
                            </Grid>
                        </Grid>
                        <Button color="inherit" onClick={logout} >LogOut</Button>
                    </Toolbar>
                </AppBar>
            </div>  
            <div className='bg'>
                {users === "true" &&
                    <div>
                        <h2>Joined Users</h2>
                        {masterarrj && masterarrj.map((item, index) => (
                            <li key={index}>{item}</li>
                        ))}
                        <h2>Pending Users</h2>
                        {masterarrp && masterarrp.map((item, index) => (
                            <li key={index}>{item}</li>
                        ))}
                        <h2>Blocked Users</h2>
                        {masterarrb && masterarrb.map((item, index) => (
                            <li key={index}>{item}</li>
                        ))}
                    </div>
                }
                {pendinguser === "true" &&
                    <div>
                        <h2>Pending Users </h2>
                        {masterarrp && masterarrp.map((name, index) => (
                            <Card
                                name={name}
                                onAccept={(e) => {e.preventDefault();add(name)}}
                                onReject={(e) => {e.preventDefault();reject(name)}}
                            />
                        ))}
                    </div>
                }
            </div>
        </div>
    )
}
export default Homesubgreddits;
