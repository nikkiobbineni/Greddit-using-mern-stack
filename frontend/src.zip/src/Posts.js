import { useParams } from "react-router-dom";
import './Log_in.css';
import Card from './Card2.js';
import { useNavigate } from 'react-router-dom';
import { AppBar, Toolbar, Button } from '@material-ui/core';
import { makeStyles } from '@material-ui/core/styles';
import { Grid } from '@material-ui/core';
import { useState, useEffect } from 'react';
const useStyles = makeStyles(() => ({ appBar: { background: 'linear-gradient(45deg, #5dc4d6 30%, #d66fc8 90%)' } }));
function Homesubgreddits() {
    const { gredditname } = useParams();
    // console.log(gredditname)
    const classes = useStyles();
    const navigate = useNavigate();
    const [pqr, setPqr] = useState("false");
    const [text, setText] = useState("");
    const [comments, setComments] = useState("");
    const [postedby, setPostedby] = useState("");
    const [postedin, setPostedin] = useState("");
    const [downvotes, setDownvotes] = useState("");
    const [addcomment,setAddcomment]=useState("")
    const username = localStorage.getItem('username');
    const [upvotes, setUpvotes] = useState("");
    const [join, setJoin] = useState("");
    var arrt = [];
    var arrc = [];
    var arrpb = [];
    var arrpi = [];
    var arru = [];
    var arrd = [];
    var arrid =[];
    const [masterarrt, setMasterarrt] = useState()
    const [masterarrc, setMasterarrc] = useState()
    const [masterarrpb, setMasterarrpb] = useState()
    const [masterarrpi, setMasterarrpi] = useState()
    const [masterarru, setMasterarru] = useState()
    const [masterarrd, setMasterarrd] = useState()
    const [masterarrid, setMasterarrid] = useState()
    function logout() {
        localStorage.removeItem('username');
        localStorage.removeItem('password');
        navigate('/');
    }
    function check() {
        navigate('/profile');
    }
    function checka() {
        navigate('/mysubgreddits');
    }
    function checkb() {
        navigate('/allsubgreddits');
    }
    function addgreddits() {
        setPqr("true")
    }
    function edits(index, a, b) {
        // console.log(upvotes)
        const fetchdata = async () => {
            console.log("this")
            const response = await fetch('http://localhost:5000/edit-posts', {
                method: 'POST',
                body: JSON.stringify({
                    "name": gredditname,
                    "text": masterarrt[index],
                    "postedby": masterarrpb[index],
                    "postedin": masterarrpi[index],
                    "comments": masterarrc[index],
                    "upvotes": masterarru[index] + a,
                    "downvotes": masterarrd[index] + b,
                    "join": join,
                }),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            const data = await response.json();
            if (response.ok) {
                console.log("YES")
                const temparr = []
                masterarru.map((elem) => {
                    temparr.push(elem)
                })
                temparr[index] += a
                setMasterarru(temparr)
                const temparr2 = []
                masterarrd.map((elem) => {
                    temparr2.push(elem)
                })
                temparr2[index] += b
                setMasterarrd(temparr2)

            }
        }

        fetchdata();
    }
    function likes(index) {
        edits(index, 1, 0)
    }
    function dislikes(index) {
        edits(index, 0, 1)
    }
    useEffect(function () {
        const fetchCredentials = async () => {
            const response = await fetch(`http://localhost:5000/get-posts/${gredditname}`);
            const data = await response.json();
            if (response.ok) {
                const { text } = data.map((e) => (
                    arrt.push(e.text)
                ));
                setMasterarrt(arrt)
                const { postedby } = data.map((e) => (
                    arrpb.push(e.postedby)
                ));
                setMasterarrpb(arrpb)
                const { postedin } = data.map((e) => (
                    arrpi.push(e.postedin)
                ));
                setMasterarrpi(arrpi)
                const { comments } = data.map((e) => (
                    arrc.push(e.comments)
                ));
                setMasterarrc(arrc)
                const { upvotes } = data.map((e) => (
                    arru.push(e.upvotes)
                ));
                setMasterarru(arru)

                const { downvotes } = data.map((e) => (
                    arrd.push(e.downvotes)
                ));
                setMasterarrd(arrd)
                const { _id } = data.map((e) => (
                    arrid.push(e._id)
                ));
                setMasterarrid(arrid)
                console.log(arrid)
                arrt = []
                arrc = []
                arrpb = []
                arrpi = []
                arrd = []
                arru = []
                arrid =[]
            }
            else {
                console.error(data.error);
            }
        };
        if (pqr === "false") {
            fetchCredentials();
        }
        /*eslint-disable-next-line*/
    }, []);
    console.log(masterarrc)
    function reset(e) {
        const fetchdata = async () => {
            const response = await fetch('http://localhost:5000/add-posts', {
                method: 'POST',
                body: JSON.stringify({
                    "name": gredditname,
                    "text": text,
                    "postedby": username,
                    "postedin": gredditname,
                    "comments": comments,
                    "upvotes": 0,
                    "downvotes": 0,
                    "join": false,
                }),
                headers: {
                    'Content-Type': 'application/json'
                }
            })
            const data = await response.json();
            console.log(data)
            if (response.ok) {
                console.log("YES")
                setMasterarrpb(localStorage.getItem('username'))
                setMasterarrpi(gredditname)
                setMasterarrt([
                    ...masterarrt,
                    text
                ])
                setMasterarrc([
                    ...masterarrc,
                    comments
                ])
                setMasterarrpb([
                    ...masterarrpb,
                    username
                ])
                setMasterarrpi([
                    ...masterarrpi,
                    gredditname
                ])
                setMasterarru([
                    ...masterarrd,
                    0
                ])
                setMasterarrd([
                    ...masterarru,
                    0
                ])
            }
            else {
                console.log("No")
            }
        }
        fetchdata();
        setPqr("false")
    }
    return (
        <div>
            <div >
                <AppBar position="static" className={classes.appBar}>
                    <Toolbar>
                        <Grid container alignItems="flex-start" justify="flex-start">
                            <Grid item>
                                <Button color="inherit" onClick={check}>Profile</Button>
                                <Button color="inherit" onClick={checka}>Mysubgreddits</Button>
                                <Button color="inherit" onClick={checkb}>Allsubgreddits</Button>
                            </Grid>
                        </Grid>
                        <Button color="inherit" onClick={logout} >LogOut</Button>
                    </Toolbar>
                </AppBar>
            </div>
            <div className='bg'>
                <div className='card-container'>
                    {masterarrt && masterarrt.map((text, index) => (
                        <Card
                            text={text}
                            postedby={masterarrpb[index]}
                            postedin={masterarrpi[index]}
                            comments={masterarrc[index]}
                            upvotes={masterarru[index]}
                            downvotes={masterarrd[index]}
                            onLike={() => likes(index)}
                            onDislike={() => dislikes(index)}
                            id={masterarrid[index]}
                            // onAdd={() => (index)}
                        />
                        
                    ))}
                </div>
                {console.log(masterarrid)}
                <div className='login-containera'>
                    <button className="add-button" type="submit" onClick={addgreddits}>ADD</button>
                    {pqr === "true" &&
                        <div className="login-box">
                            <div className="h2">
                                <h2>NEW SUB GREDDIT</h2>
                            </div>
                            <label>
                                <br />
                                <input
                                    className="input-field"
                                    placeholder="Text"
                                    type="text"
                                    value={text}
                                    onChange={(e) => { setText(e.target.value); }}
                                />
                            </label>
                            {/* <label>
                                <br />
                                <input
                                    className="input-field"
                                    placeholder="Postedby"
                                    type="text"
                                    value={postedby}
                                    onChange={(e) => { setPostedby(e.target.value); }}
                                    setPostedby(localStorage.getItem('username'))
                                />
                            </label>
                            <label>
                                <br />
                                <input
                                    className="input-field"
                                    placeholder="Postedin"
                                    type="text"
                                    value={postedin}
                                    onChange={(e) => { setPostedin(e.target.value); }}
                                />
                            </label> */}
                            <label>
                                <br />
                                <input
                                    className="input-field"
                                    placeholder="Comments"
                                    type="text"
                                    value={comments}
                                    onChange={(e) => { setComments(e.target.value); }}
                                />
                            </label>
                            <button className="save-button" type="submit" onClick={reset}>SAVE</button>
                        </div>
                    }
                </div>
            </div>
        </div>
    )
}
export default Homesubgreddits;
