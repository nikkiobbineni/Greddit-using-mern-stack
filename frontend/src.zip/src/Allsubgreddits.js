import './Log_in.css';
import Card from './Card3.js';
import { useNavigate } from 'react-router-dom';
import { AppBar, Toolbar, Button } from '@material-ui/core';
import { useState, useEffect } from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Grid } from '@material-ui/core';
const useStyles = makeStyles(() => ({ appBar: { background: 'linear-gradient(45deg, #5dc4d6 30%, #d66fc8 90%)' } }));
function Allsubgreddits() {
  const classes = useStyles();
  const navigate = useNavigate();
  const [pqr, setPqr] = useState("false");
  const [description, setDescription] = useState("");
  const [tags, setTags] = useState("");
  const [name, setName] = useState("");
  const [joinedusers, setjoinedusers] = useState("")
  // const [post, setPost] = useState("");
  var arrn = [];
  var arrd = [];
  var arrt = [];
  var arrk = [];
  var arrj = [];
  const [masterarrn, setMasterarrn] = useState()
  const [masterarrd, setMasterarrd] = useState()
  const [masterarrt, setMasterarrt] = useState()
  const [masterarrk, setMasterarrk] = useState()
  const [masterarrj, setMasterarrj] = useState()
  const [bannedwords, setBannedwords] = useState("");
  const [searchQuery, setSearchQuery] = useState("");
  const [searchtag, setSearchtag] = useState("");
  function logout() {
    localStorage.removeItem('username');
    localStorage.removeItem('password');
    navigate('/');
  }
  function check() {
    navigate('/profile');
  }
  function checka() {
    navigate('/mysubgreddits');
  }
  function addgreddits() {
    setPqr("true")
  }
  useEffect(function () {
    const fetchCredentials = async () => {
      // const username = localStorage.getItem('username');
      const response = await fetch(`http://localhost:5000/get-allsubgreddits`);
      const data = await response.json();
      // console.log(data)
      if (response.ok) {
        const { name } = data.map((e) => (
          arrn.push(e.name)
        ));
        setMasterarrn(arrn)
        console.log(masterarrn)
        const { description } = data.map((e) => (
          arrd.push(e.description)
        ));
        setMasterarrd(arrd)
        console.log(masterarrd)
        const { tags } = data.map((e) => (
          arrt.push(e.tags)
        ));
        setMasterarrt(arrt)
        const { bannedwords } = data.map((e) => (
          arrk.push(e.bannedwords)
        ));
        setMasterarrk(arrk)
        const { joinedusers } = data.map((e) => (
          arrj.push(e.joinedusers)
        ));
        // arrj.push(localStorage.getItem('username'))
        setMasterarrj(arrj)
        arrd = []
        arrn = []
        arrk = []
        arrt = []
        arrj = []
      }
      else {
        console.error(data.error);
      }
    };
    if (pqr === "false") {
      fetchCredentials();
    }
    /*eslint-disable-next-line*/
  }, []);
  console.log(masterarrj)
  function opens(name) {
    navigate(`/allsubgreddits/${name}`);
  }
  function reset() {
    const fetchdata = async () => {
      const response = await fetch('http://localhost:5000/add-subgreddits/', {
        method: 'POST',
        body: JSON.stringify({
          "username": localStorage.getItem('username'),
          "name": name,
          "description": description,
          "tags": tags,
          "bannedwords": bannedwords,
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const data = await response.json();
      if (response.ok) {
        console.log("YES")
        setMasterarrn([
          ...masterarrn,
          name
        ])
        setMasterarrd([
          ...masterarrd,
          description
        ])
        setMasterarrt([
          ...masterarrt,
          tags
        ])
        setMasterarrk([
          ...masterarrk,
          bannedwords
        ])
      }
      else {
        console.log("No")
      }
    }
    fetchdata();
    setPqr("false")
  }
  // function search(){
  //   setSearch("yes")
  // }
  // console.log(masterarrj)

  return (
    <div>
      {console.log(arrn)}
      <div >
        <AppBar position="static" className={classes.appBar}>
          <Toolbar>
            <Grid container alignItems="flex-start" justify="flex-start">
              <Grid item>
                <Button color="inherit" onClick={check}>Profile</Button>
                <Button color="inherit" onClick={checka}>Mysubgreddits</Button>
                <Button color="inherit">Allsubgreddits</Button>
              </Grid>
            </Grid>
            <Button color="inherit" onClick={logout} >LogOut</Button>
          </Toolbar>
        </AppBar>
      </div>
      <div className='bg'>
        <div className='search-bar'>
          <input
            type="text"
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search..."
          />
        </div>
        <br />
        <div className='search-bar'>
          <input
            type="text"
            value={searchtag}
            onChange={(e) => setSearchtag(e.target.value)}
            placeholder="Search tags..."
          />
        </div>
        <br />
        <div className='card-container'>
          {masterarrn && masterarrn.map((name, index) => {
            if (searchQuery && !name.toLowerCase().includes(searchQuery.toLowerCase())) {
              return null;
            }
            // if (searchtag) {
            //   const tagList = searchtag.split(',').map(tag => tag.trim().toLowerCase());
            //   if (!tagList.some(tag => tags.includes(tag))) {
            //     return null;
            //   }
            // }
            if (searchtag) {
              const tags = masterarrt[index].split(',').map(tag => tag.trim());
              const searchTags = searchtag.split(',').map(tag => tag.trim());
              if (!searchTags.some(tag => tags.includes(tag))) {
                return null;
              }
            }
            
            // {console.log(masterarrj[index])}
            return (
              <Card
                name={name}
                description={masterarrd[index]}
                tags={masterarrt[index]}
                bannedkeywords={masterarrk[index]}
                joinedusers={masterarrj[index]}
                onOpen={() => opens(name)}
              />
            );
          })}

        </div>
        <div className='login-containera'>
          {/* <button className="add-button" type="submit" onClick={addgreddits}>ADD</button> */}
          {pqr === "true" &&
            <div className="login-box">
              <div className="h2">
                <h2>NEW SUB GREDDIT</h2>
              </div>
              <label>
                <br />
                <input
                  className="input-field"
                  placeholder="Name"
                  type="text"
                  value={name}
                  onChange={(e) => { setName(e.target.value); }}
                />
              </label>
              <label>
                <br />
                <input
                  className="input-field"
                  placeholder="Description"
                  type="text"
                  value={description}
                  onChange={(e) => { setDescription(e.target.value); }}
                />
              </label>
              <label>
                <br />
                <input
                  className="input-field"
                  placeholder="Tags"
                  type="text"
                  value={tags}
                  onChange={(e) => { setTags(e.target.value); }}
                />
              </label>
              <label>
                <br />
                <input
                  className="input-field"
                  placeholder="Banned Keywords"
                  type="text"
                  value={bannedwords}
                  onChange={(e) => { setBannedwords(e.target.value); }}
                />
              </label>
              <button className="save-button" type="submit" onClick={reset}>SAVE</button>
            </div>
          }
        </div>
      </div>
    </div>
  )
}
export default Allsubgreddits;