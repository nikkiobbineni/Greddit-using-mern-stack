import './Card.css'
// import { useParams } from "react-router-dom";
import React from 'react';
// import { useState, useEffect } from 'react';
const Card = (props) => {
  return (
    <div className="card">
      <div className="card-content">
        <h2>Text: {props.text}</h2>
        <p>Postedby: {props.postedby}</p>
        <p>Postedin: {props.postedin}</p>
        <p>Comments : {props.comments}</p>
        <p>Upvotes : {props.upvotes}</p>
        <p>Downvotes : {props.downvotes}</p>
      </div>
    </div>
  );
};
export default Card;
