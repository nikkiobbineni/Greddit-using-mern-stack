import './Card.css'
import React from 'react';

const Card = (props) => {
  console.log(props.name);
  console.log("wkdjwe")
  return (
    <div className="card">
      <div className="card-content">
        <h2>Name: {props.name}</h2>
        <p>Description: {props.description}</p>
        <p>Tags: {props.tags}</p>
        <p>Banned Key words: {props.bannedkeywords}</p>
        <p>Number of people: {props.followers}</p>
        <p>Number of posts : {props.postscount}</p>
        <button onClick={props.onDelete}>Delete</button>
        <button onClick={props.onOpen}>Open</button>
      </div>
    </div>
  );
};

export default Card;
