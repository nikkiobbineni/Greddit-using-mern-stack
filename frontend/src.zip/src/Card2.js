import './Card.css'
import { useParams } from "react-router-dom";
// import '/Log_in.css'
import React from 'react';
import { useState, useEffect } from 'react';
const Card = (props) => {
  console.log(props.name);
  const { gredditname } = useParams();
  let x=[]
  const [addcomment, setAddcomment] = useState("false")
  const [newcomment, setNewcomment] = useState("")
  const [joins,setJoins] = useState("true")
  const [xyz, setXyz] = useState(props.comments)
  function saves() {
    const fetchdata = async () => {
      console.log("this")
      const response = await fetch('http://localhost:5000/add-posting', {
        method: 'POST',
        body: JSON.stringify({
          "username" : localStorage.getItem('username'),
          "savedposts" : props.id
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const data = await response.json();
      console.log(props.id)
      if(response.ok)
      {
        setXyz([
          ...xyz,
          newcomment
        ])
      }
    }
    fetchdata();
  }
  function follow2() {
    const fetchdata = async () => {
      console.log("this")
      const response = await fetch('http://localhost:5000/follower', {
        method: 'POST',
        body: JSON.stringify({
          "username" : localStorage.getItem('username'),
          "following" : props.postedby
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const data = await response.json();
      console.log(props.id)
    }
    fetchdata();
  }
  function follow() {
    const fetchdata = async () => {
      console.log("this")
      const response = await fetch('http://localhost:5000/following', {
        method: 'POST',
        body: JSON.stringify({
          "username" : localStorage.getItem('username'),
          "following" : props.postedby
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const data = await response.json();
      console.log(props.id)
    }
    fetchdata();
    follow2();
  }
  function check()
  {
    if(props.postedby === localStorage.getItem('username'))
    {
     setJoins("false");
    }
  }
  function checkb()
  {
    // if(props.postedby === localStorage.getItem('username'))
    {
     setJoins("true");
    }
  }
  function adds() {
    let x = [...props.comments, newcomment];
    setAddcomment("false");
    const fetchdata = async () => {
      console.log("this")
      const response = await fetch('http://localhost:5000/edit-posts', {
        method: 'POST',
        body: JSON.stringify({
          "name": gredditname,
          "text": props.text,
          "postedby": props.postedby,
          "postedin": props.postedin,
          "comments": x,
          "upvotes": props.upvotes,
          "downvotes": props.downvotes,
          "join": false,
        }),
        headers: {
          'Content-Type': 'application/json'
        }
      })
      const data = await response.json();
      if(response.ok)
      {
        setXyz([
          ...xyz,
          newcomment
        ])
      }
    }
    fetchdata();
  }
  function adding() {
    setAddcomment("true");
  }
  return (
    <div className="card">
      <div className="card-content">
        <h2>Text: {props.text}</h2>
        <p>Postedby: {props.postedby}</p>
        <p>Postedin: {props.postedin}</p>
        <p>Comments : {xyz}</p>
        <p>Upvotes : {props.upvotes}</p>
        <p>Downvotes : {props.downvotes}</p>
        <button onClick={props.onLike}>Upvote</button>
        <button onClick={props.onDislike}>Downvote</button>
        <button onClick={adding}>Add Comment</button>
        <button onClick={saves}>Save post</button>
        <button onClick={follow}>Follow user</button>
        <button onClick={saves}>Report post</button>
        {/* {props.po === "true" &&
          <button >Join</button>
        } */}
        {addcomment === "true" &&
          <div className="login-box">
            <div className="h2">
              <h2>NEW SUB GREDDIT</h2>
            </div>
            <label>
              <br />
              <input
                className="input-field"
                placeholder="Command"
                type="text"
                value={newcomment}
                onChange={(e) => { setNewcomment(e.target.value); }}
              />
            </label>
            <button className="save-button" type="submit" onClick={adds}>SAVE</button>
          </div>
        }
        {

        }
      </div>
    </div>
  );
};
export default Card;
