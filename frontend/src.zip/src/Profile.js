import './Profile.css';
import { useNavigate} from 'react-router-dom';
import { AppBar, Toolbar, Button } from '@material-ui/core';
import { useState} from 'react';
import { makeStyles } from '@material-ui/core/styles';
import { Grid } from '@material-ui/core';
const useStyles = makeStyles(() => ({appBar: {background: 'linear-gradient(45deg, #5dc4d6 30%, #d66fc8 90%)'}}));
function Profile()
{
    const classes = useStyles();
    const navigate = useNavigate();
    const [fname, setFname] = useState("");
    const [email, setEmail] = useState(""); 
    const [edit  ,setEdit]=useState("false");
    function change()
    {
      if(edit==="false")
      {
     const fetchCredentials = async () => {
      const username = localStorage.getItem('username');
      const response = await fetch(`http://localhost:5000/get-credentials/${username}`);
      const data = await response.json();
      if (response.ok) {
        const { fname, email } = data;
        setFname(fname);
        setEmail(email)
        console.log(`FNAME: ${fname}, Email: ${email}`);
      } else {
        console.error(data.error);
      }
    };
     fetchCredentials();  
  }  
  }
  change();

  function followers()
  {
    
  }
  function logout() 
    {
        localStorage.removeItem('username');
        localStorage.removeItem('password');
        navigate('/');
    }
    function check() 
    {
        navigate('/mysubgreddits');
    } 
    function checka() 
    {
        navigate('/allsubgreddits');
    } 
    function preedits() 
    {
        setEdit("true");
    } 
    function edits() 
    {
        const fetchdata = async () => {
            console.log("this")
            const response = await fetch('http://localhost:5000/edit-credentials', {
              method: 'POST',
              body: JSON.stringify({
                "fname": fname,
                "username":  localStorage.getItem('username'),
                "email": email,
              }),
              headers: {
                'Content-Type': 'application/json'
              }
            })
            const data = await response.json();
            if (response.ok) {
                console.log("YES")
                setEdit("false");
              }
          }
        
          fetchdata();
  }

    if(localStorage.getItem('username') && localStorage.getItem('password'))
    return (
        <div className='profile'>
        <AppBar position="static" className={classes.appBar}>
        <Toolbar>
        <Grid container alignItems="flex-start" justify="flex-start">
        <Grid item>
            <Button color="inherit">Profile</Button>
            <Button color="inherit" onClick={check}>Mysubgreddits</Button>
            <Button color="inherit" onClick={checka}>Allubgreddits</Button>
        </Grid>
        </Grid>
            <Button color="inherit" onClick={logout} >LogOut</Button>
        </Toolbar>
        </AppBar>
            <h1>PROFILE</h1>
           <div className='profile-box'>
           <img src="https://cdn0.iconfinder.com/data/icons/social-messaging-ui-color-shapes/128/user-female-circle-pink-512.png" alt="Italian Trulli" width="80" height="80"/>
           <br />
           <br />
            <div style={{textAlign:"center" ,fontWeight: "bold",fontSize: "25px"}}>{fname}</div>
            <br />
            <div style={{textAlign:"center",fontSize: "20px"}}>{email}</div>
            <br />
            <br />
            {edit === "true" &&
            <div>
                 <input
                className="input-field"
                placeholder="Enter FirstName"
                value={fname}
                type="text"
                onChange={(e) => { setFname(e.target.value) }}
              />
              <input
                className="input-field"
                placeholder="Mail"
                value={email}
                type="email"
                onChange={(e) => { setEmail(e.target.value) }}
              />
            <br />
            <button type="submit" onClick={edits}>SAVE</button>
            </div>
             }
              <button type="submit" onClick={preedits}>EDIT</button>
              {/* <button type="submit" onClick={following}>FOLLOWERS</button> */}
              {/* <button type="submit" onClick={preedits}>FOLLOWING</button> */}
            </div> 
        </div>
    );
    else 
    {
      window.location="/";
    }
}
export default Profile;