import './Card.css'
import React from 'react';
import { useState, useEffect } from 'react';
const Card = (props) => {
     var arrt = []
       const [post, setPost] = useState(0);
function joinreq()
{
    const fetchdata = async () => {
        console.log("this")
        const response = await fetch('http://localhost:5000/join-req', {
          method: 'POST',
          body: JSON.stringify({
            "username" : localStorage.getItem('username'),
            "name" : props.name
          }),
          headers: {
            'Content-Type': 'application/json'
          }
        })
        const data = await response.json();
        console.log(props.id)
      }
      fetchdata();
}
function postcount(gredditname)
{
    console.log("njcsfd")
    const fetchCredentials = async () => {
        const response = await fetch(`http://localhost:5000/get-posts/${gredditname}`);
        const data = await response.json();
        if (response.ok) {
            const { text } = data.map((e) => (
                arrt.push(e.text)
            ));
        //    console.log(arrt.length) 
            setPost(arrt.length)
        }
    };
    fetchCredentials();
}
  return (
    <div className="card">
      <div className="card-content">
        <h2>Name: {props.name}</h2>
        <p>Description: {props.description}</p>
        <p>Tags: {props.tags}</p>
        <p>Banned Key words: {props.bannedkeywords}</p>
        <p>Number of people: {props.joinedusers.length-1}</p>
        {postcount(props.name)}
        <p>Number of posts : {post}</p>
        {/* {console.log(props.tags)} */}
     {props.joinedusers.includes(localStorage.getItem('username')) &&
     <div>
        <button onClick={props.onOpen}>Open</button>
        <button>Leave</button>
        </div>
     }
     {!props.joinedusers.includes(localStorage.getItem('username')) &&
        <button onClick={joinreq}>Join</button>
     }
      </div>
    </div>
  );
};

export default Card;
